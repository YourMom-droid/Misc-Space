
---

# README

## Introduction

Hi,

This is my first time uploading on this board, so I am not entirely familiar with the process. I would like to express my appreciation for ricehit's hard work; this mod is truly gorgeous and fabulous.

However, I couldn't find any English translations, which is why I created this version.

## Purpose

This release is intended for the English translation and Android compatibility, supporting dialogue with at least 21,534 lines.

I am aware that the official English translation is currently in progress. However, I wish to release this version as the mod is unplayable without English dialogue; it often displays blank spaces. That's why I released this version.

## Background

As an Android user, it is particularly challenging for us to make some mods compatible due to differences in the StardewValley.dll code between PC and Android versions. Even though we are now closer to the current PC versions, it still remains difficult to get everything working properly due to issues such as:

- Missing API
- BOM code
- Runtime
- Strings
- Software compatibility

This is why I decided to release this mod.

## Compatibility Fixes

Firstly, our issues are not from SDS. It appears that the problem is with the Producer Framework Mod (PFM), which tends to crash when using any chest or certain menus.

We have been aware of this issue since version 1.5.6. It was working on version 1.6.14.11, but problems resurfaced in version 1.6.15, bringing us back to Abyss.

To resolve this, I converted the PFM mod into a Content Patcher (CP) dependency instead, which works fine and is compatible with the original mod.

**Note:** Don't worry about the changes; I have left the same UniqueID in the folder, with a new name to distinguish the differences in SMAPI/ErrorLogs.

## Credits and Acknowledgments

### Original Mod:
- [Producer Framework Mod by ricehit](https://www.nexusmods.com/stardewvalley/mods/15100)

### Huge Thanks to:
- **ricehit** (Author of the Original Mod, Copyright Ownership)
  - [Nexus Mods Profile](https://www.nexusmods.com/stardewvalley/users/97247953)

- **NRT Naratip** (SMAPI Android Developer)
  - [GitHub Profile](https://github.com/NRTnarathipstar)

---
